using Terraria.ModLoader;

namespace WitherLordsTest
{
	public class WitherLordsTest : Mod
	{
	}
}